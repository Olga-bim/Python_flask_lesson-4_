from flask import Flask, redirect, render_template, url_for

app = Flask(__name__)

# Sample data to pass to the template
users = [
    {'id': 1, 'name': 'John Doe', 'age': 30, 'email': 'john@example.com', 'admin': True},
    {'id': 2, 'name': 'Jane Smith', 'age': 25, 'email': 'jane@example.com', 'admin': False},
    {'id': 3, 'name': 'Emily Davis', 'age': 40, 'email': 'emily@example.com', 'admin': False},
    {'id': 4, 'name': 'Michael Brown', 'age': 35, 'email': 'michael@example.com', 'admin': True},
    {'id': 5, 'name': 'Sarah Johnson', 'age': 28, 'email': 'sarah@example.com', 'admin': False},
    {'id': 6, 'name': 'David Wilson', 'age': 45, 'email': 'david@example.com', 'admin': True},
    {'id': 7, 'name': 'Laura Martinez', 'age': 32, 'email': 'laura@example.com', 'admin': False},
    {'id': 8, 'name': 'James Anderson', 'age': 38, 'email': 'james@example.com', 'admin': True},
    {'id': 9, 'name': 'Olivia Taylor', 'age': 29, 'email': 'olivia@example.com', 'admin': False},
    {'id': 10, 'name': 'William Thomas', 'age': 50, 'email': 'william@example.com', 'admin': False},
    {'id': 11, 'name': 'Ava Harris', 'age': 26, 'email': 'ava@example.com', 'admin': True},
    {'id': 12, 'name': 'Ethan Clark', 'age': 31, 'email': 'ethan@example.com', 'admin': False},
    {'id': 13, 'name': 'Mia Lewis', 'age': 27, 'email': 'mia@example.com', 'admin': True},
    {'id': 14, 'name': 'Alexander Walker', 'age': 33, 'email': 'alexander@example.com', 'admin': False},
    {'id': 15, 'name': 'Sophia Young', 'age': 42, 'email': 'sophia@example.com', 'admin': False}
]
@app.route('/')
def index():
    # n1 = 9
    return  render_template('hello.html',  users=users)

@app.route('/user/<int:user_id>')
def user_details(user_id):
    user = next((user for user in users if user['id'] == user_id), None)
    if user is None:
        return redirect(url_for('index'))
    return render_template('user_details.html', user=user)

@app.route('/sport')
def sporttt():
    return  render_template('sport.html', users=users)

@app.route('/news')
def nnnnews():
    return  render_template('news.html')

if __name__ == '__main__':
    app.run(debug=True)
